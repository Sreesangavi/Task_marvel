
function calculate(quantity, servingVal) {
   

    // highlight the color for selected serving 
    var otherElt = document.getElementsByClassName("serving");
    $(otherElt).css("border", "1px solid grey");
    $(otherElt).removeClass("highlight");
    
    var servingElt = document.getElementsByClassName("serving"+servingVal);
    $(servingElt).css("border", "3px solid #0099FF");
    $(servingElt).addClass("highlight");
       
    // Get the current oval position to toggle between Anually and Montly 
    // Oval - Setting style left: 685px for Anually and left: 720px
    var ovalElt = document.getElementsByClassName('oval');
    var ovalPosition = $(ovalElt).css("left");
    
    display(quantity, ovalPosition);
}

function toggleBilling() {
    // Get the oval position and set left as per toggle
    var ovalElt = document.getElementsByClassName('oval');
    var ovalPosition = $(ovalElt).css("left");
    
    if (ovalPosition == "685px") {
        $(ovalElt).css("left","720px");
        ovalPosition = "720px";
     } else {
        $(ovalElt).css("left","685px");
        ovalPosition = "685px";
     }
   
    var elt = document.getElementsByClassName("highlight");
    currQuantity = $(elt).attr("value");

    display(currQuantity, ovalPosition);
}


function display(quantity, ovalPosition ){
    var lol,ice;
    if (ovalPosition == "685px") {
    lol = 0.5;
    ice = 1;
    } else {
        lol = 1;
        ice = 2; 
    }

    var lolPrice = (quantity * lol); 
    var icePrice = (quantity * ice); 
    var savings = icePrice-lolPrice;

    // Populate the values as per the price calculated
    var lolElt = document.getElementsByClassName('lolPrice');
    $(lolElt)[0].innerHTML = "$"+lolPrice+"<span class=body-copy-36>Per Month </span><p class=body-copy-5>For "+quantity+" Serving</p>";
    var iceElt = document.getElementsByClassName('icePrice');
    $(iceElt)[0].innerHTML = "$"+icePrice+"<span class=body-copy-36>Per Month </span><p class=body-copy-5>For "+quantity+" Serving</p>";
    var savingsElt = document.getElementsByClassName('savings');
    $(savingsElt)[0].innerHTML = "$"+savings+"<p class=body-copy-36>Per Month </p>";
}