var express = require('express');
//var request = require('request');
const path = require('path');
var app = express();
app.set('view engine', 'ejs');
app.use(express.static('public'));
const PORT = process.env.PORT || 5000

app.get('/', function(req, res){
    res.render('index');
});

app.listen(PORT, () => console.log(`Listening on ${ PORT }`));